package org.interview.rieshr.task.ccnumgenrator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


/**
 * Created by Ashok Kr Singh on 29-09-2018.
 */
@SpringBootApplication(scanBasePackages = {"org.interview.rieshr.task.ccnumgenrator"})
public class CcNumGenratorApplicationLauncher {

    public static void main(String[] args) {
        System.setProperty("server.servlet.context-path", "/ccapp");
        SpringApplication.run(CcNumGenratorApplicationLauncher.class, args);
    }
}
