package org.interview.rieshr.task.ccnumgenrator.StoreCards;

import javax.inject.Named;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Created by ashok on 30-09-2018.
 */
@Named
public class WriteDataToFile {

    public void writeCcDataToFile(List<String> ccList){
          try(FileWriter fw = new FileWriter("ValidCredits.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw))
          {
                for(String s :ccList){
                    out.print(s);
                }
          } catch (IOException e) {
                System.out.println("Exception Occurred while Writing the Credit Card Numbers");
                e.printStackTrace();
           }
    }
}
