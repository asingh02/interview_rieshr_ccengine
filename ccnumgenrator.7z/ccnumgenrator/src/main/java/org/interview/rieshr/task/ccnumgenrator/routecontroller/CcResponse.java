package org.interview.rieshr.task.ccnumgenrator.routecontroller;

import javax.inject.Named;
import java.util.List;

/**
 * Created by ashok on 30-09-2018.
 */
@Named
public class CcResponse {

    private String status;
    private List<String> ccNumbers;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<String> getCcNumbers() {
        return ccNumbers;
    }

    public void setCcNumbers(List<String> cc) {
        this.ccNumbers = cc;
    }
}

