package org.interview.rieshr.task.ccnumgenrator.util;

import javax.inject.Named;

/**
 * Created by Ashok Kr Singh on 29-09-2018.
 */
@Named
public class GenerateNumber {

    public String generateCcNumber(String prefix, int len){
        String ccDigits = prefix;

        while(ccDigits.length()<(len-1)){
            ccDigits = ccDigits+ new Double(Math.floor(Math.random() * 10)).intValue();
        }

        String newCcDigits= reverseString(ccDigits);

        int[] digitArray = new int[newCcDigits.length()];
        for(int i = 0; i < digitArray.length; i++){
            digitArray[i] = Integer.valueOf(String.valueOf(newCcDigits.charAt(i)));
        }

        int sum = 0;
        int pos = 0;

        while( pos < (len-1) ){
            int val = digitArray[pos] * 2;
            if(val > 9){
                val -= 9;
            }
            sum += val;

            if(pos != len - 2){
                sum += digitArray[pos + 1];
            }

            pos += 2;
        }

        int checkdigit = new Double(
        ((Math.floor(sum / 10) + 1) * 10 - sum) % 10).intValue();

        ccDigits += checkdigit;

        return ccDigits;
    }

    static String reverseString(String str) {
        if (str == null)
            return "";

        String revstr = "";
        for (int i = str.length() - 1; i >= 0; i--) {
            revstr += str.charAt(i);
        }
        return revstr;

    }
}
