package org.interview.rieshr.task.ccnumgenrator.util;

import javax.inject.Named;
import java.util.List;

/**
 * Created by ashok on 30-09-2018.
 */
@Named
public class DisplayUtils {
    public void displayListOfString(List<String> stringList, String ccType){
        if(stringList.size()> 0) {
            System.out.println("####### "+ ccType + " CREDIT CARD NUMBER LIST  #########");
            for (String str : stringList) {
                System.out.println(str);
            }
            System.out.println("####### END CREDIT CARD NUMBER LIST  #########");
        }else
        {
            System.out.println("No credit card number number in the list");
        }
    }
}
