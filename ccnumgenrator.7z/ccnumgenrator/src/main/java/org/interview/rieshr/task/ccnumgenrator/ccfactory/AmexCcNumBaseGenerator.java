package org.interview.rieshr.task.ccnumgenrator.ccfactory;

import org.interview.rieshr.task.ccnumgenrator.util.CcType;
import org.interview.rieshr.task.ccnumgenrator.util.DisplayUtils;
import org.interview.rieshr.task.ccnumgenrator.util.GenerateNumber;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;


/**
 * Created by ashok on 29-09-2018.
 */
@Named
public class AmexCcNumBaseGenerator implements CcNumBaseGenerator {

    static final String AMEX_PREFIX="37";
    static final int AMEX_CC_LENGTH =15;

    @Inject
    private GenerateNumber generateNumber;

    @Inject
    private DisplayUtils displayUtils;

    @Override
    public List<String> generateCreditCardNumber(int numOfCard) {
        List<String> amexCardNumberList = new ArrayList<>();
        int i = 1;
        System.out.println("Number of Amex CC needs to be generated :" + numOfCard);
        while(i <= numOfCard){
            amexCardNumberList.add(generateNumber.generateCcNumber(AMEX_PREFIX,AMEX_CC_LENGTH));
        }
        displayUtils.displayListOfString(amexCardNumberList, CcType.AMERICAN_EXPRESS.toString());
        return amexCardNumberList;
    }
}
