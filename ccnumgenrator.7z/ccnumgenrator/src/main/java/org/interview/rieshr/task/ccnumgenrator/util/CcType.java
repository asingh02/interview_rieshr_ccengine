package org.interview.rieshr.task.ccnumgenrator.util;

/**
 * Created by ashok on 29-09-2018.
 */
public enum CcType {
    VISSA,
    VISA,
    MASTERCARD,
    AMERICAN_EXPRESS,
    DISCOVER_CARDS
}
