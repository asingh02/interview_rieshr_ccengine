package org.interview.rieshr.task.ccnumgenrator.ccfactory;

/**
 * Created by ashok on 30-09-2018.
 */
public abstract class CcNumGenerationBaseFactory {

    public abstract CcNumBaseGenerator getCreditCardTypeInstc(String cardType);
}
