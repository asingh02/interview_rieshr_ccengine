package org.interview.rieshr.task.ccnumgenrator.ccvalidationengine.service;

import javax.inject.Named;
import java.util.List;
import java.util.concurrent.Callable;

/**
 * Created by Ashok Kr Singh on 30-09-2018.
 */

public class CcValidationCheckService implements Callable<String>{

    private String ccNumber;

    public CcValidationCheckService(String cc){
        this.ccNumber =  cc;
    }

    public String call() throws Exception{
        boolean val = validateCcNumber(ccNumber);
        if(val){
            return ccNumber;
        }else
        {
            return "";
        }
    }

    public static boolean validateCcNumber(String ccNumber) {
        boolean isValid = Boolean.FALSE;
        try {
            String reversedCcNumber = new StringBuffer(ccNumber).reverse().toString();

            int mod10Count = 0;

            for (int i = 0; i < reversedCcNumber.length(); i++) {
                int reversed = Integer.parseInt(String.valueOf(reversedCcNumber.charAt(i)));
                if (((i + 1) % 2) == 0) {
                    String productString = String.valueOf(reversed * 2);
                    reversed = 0;
                    for (int j = 0; j < productString.length(); j++) {
                        reversed += Integer.parseInt(String.valueOf(productString.charAt(j)));
                    }
                }
                mod10Count += reversed;
            }

            if ((mod10Count % 10) == 0) {
                isValid = Boolean.TRUE;
            }

        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return isValid;
    }
}
