
package org.interview.rieshr.task.ccnumgenrator.ccfactory;

import java.util.List;
/**
 * Created by Ashok Kr Singh on 29-09-2018.
 */

public interface CcNumBaseGenerator {

    public List<String> generateCreditCardNumber( int numOfCard);
}