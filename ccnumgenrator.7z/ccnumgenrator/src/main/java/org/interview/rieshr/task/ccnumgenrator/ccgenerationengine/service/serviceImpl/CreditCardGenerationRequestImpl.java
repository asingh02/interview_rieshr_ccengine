package org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service.serviceImpl;

import org.interview.rieshr.task.ccnumgenrator.StoreCards.WriteDataToFile;
import org.interview.rieshr.task.ccnumgenrator.ccfactory.CcNumBaseGenerator;
import org.interview.rieshr.task.ccnumgenrator.ccfactory.CcNumGeneratorFactory;
import org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service.CreditCardGenerationRequest;
import org.interview.rieshr.task.ccnumgenrator.ccvalidationengine.service.ValidationServiceExecutor;
import org.interview.rieshr.task.ccnumgenrator.util.DisplayUtils;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import javax.inject.Qualifier;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ashok on 30-09-2018.
 */
@Service
public class CreditCardGenerationRequestImpl implements CreditCardGenerationRequest {

    @Inject
    CcNumGeneratorFactory ccNumGeneratorFactory;

    @Inject
    ValidationServiceExecutor validationServiceExecutor;

    @Inject
    WriteDataToFile writeDataToFile;
    public List<String> processRequestForCreditCardGeneration(String cardType, int numOfCards){
        CcNumBaseGenerator ccNumBaseGenerator;
        List<String> ccNums=new ArrayList<>();
        if(cardType != null){
            ccNumBaseGenerator = ccNumGeneratorFactory.getCreditCardTypeInstc(cardType);
            if (ccNumBaseGenerator!=null){
                ccNums = ccNumBaseGenerator.generateCreditCardNumber(numOfCards);
                //validating Cards
                ccNums = validationServiceExecutor.validateCard(ccNums);
                //Writing Data
                writeDataToFile.writeCcDataToFile(ccNums);
            }else{
                System.out.println("Not a valid Card Type");
            }

        }else{
            System.out.println("Card Type is empty. Please send Card Type");
        }
        return ccNums;
    }
}
