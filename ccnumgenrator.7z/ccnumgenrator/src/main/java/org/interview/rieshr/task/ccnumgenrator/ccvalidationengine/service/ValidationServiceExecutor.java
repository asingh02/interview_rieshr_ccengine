package org.interview.rieshr.task.ccnumgenrator.ccvalidationengine.service;

import javax.inject.Named;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by ashok on 30-09-2018.
 */
@Named
public class ValidationServiceExecutor {

    private ExecutorService executorService = Executors.newFixedThreadPool(10);

    public List<String> validateCard(List<String> ccList){
        LocalDate localDate = LocalDate.now();
        List<Future<String>> futureList =  new ArrayList<>();
        for(int i = 0; i< ccList.size() ; i++){
            Future<String> future = executorService.submit(new CcValidationCheckService(ccList.get(i)));
            futureList.add(future);
        }
        List<String> validList = new ArrayList<>();
        for(Future<String> fut: futureList){
            try{
                if(!fut.equals("")){
                    String str = fut.get();
                    str = str+" , "+localDate;
                    validList.add(str);
                }
            }catch(InterruptedException ex){
                ex.printStackTrace();
            }catch (ExecutionException e){
                e.getStackTrace();
            }
        }
        return validList;
    }
}
