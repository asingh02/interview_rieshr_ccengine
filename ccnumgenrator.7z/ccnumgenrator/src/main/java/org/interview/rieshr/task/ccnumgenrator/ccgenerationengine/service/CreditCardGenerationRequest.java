package org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service;

import javax.inject.Named;
import java.util.List;

/**
 * Created by ashok on 30-09-2018.
 */
@Named
public interface CreditCardGenerationRequest {

    public List<String> processRequestForCreditCardGeneration(String cardType, int numOfCards);
}

