package org.interview.rieshr.task.ccnumgenrator.routecontroller;

import org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service.CreditCardGenerationRequest;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;


/**
 * Created by ashok on 30-09-2018.
 */
@RestController
@RequestMapping("/ccengine")
public class CreditCardGenController {
    private static final String SUCCESS_CODE ="success";
    private static final String ERROR_CODE = "error";

    @Inject
    CreditCardGenerationRequest creditCardGenerationRequestImpl;


    @RequestMapping(value="/genCc" , method = RequestMethod.GET)
    @ResponseBody
    public CcResponse generateCcNumbers(@RequestParam("cardType") String cardTpye , @RequestParam("numOfCard") String numOfCard){
        CcResponse responseVal = new CcResponse();
        try{
            responseVal.setCcNumbers(creditCardGenerationRequestImpl.processRequestForCreditCardGeneration(cardTpye,Integer.valueOf(numOfCard)));
            responseVal.setStatus(SUCCESS_CODE);
        }catch(Exception e){
            responseVal.setStatus(ERROR_CODE);
        }
        return responseVal;
    }
}
