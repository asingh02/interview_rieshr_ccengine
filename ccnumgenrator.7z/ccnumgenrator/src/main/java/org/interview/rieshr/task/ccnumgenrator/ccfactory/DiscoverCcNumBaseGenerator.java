package org.interview.rieshr.task.ccnumgenrator.ccfactory;

import org.interview.rieshr.task.ccnumgenrator.util.CcType;
import org.interview.rieshr.task.ccnumgenrator.util.DisplayUtils;
import org.interview.rieshr.task.ccnumgenrator.util.GenerateNumber;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by ashok on 29-09-2018.
 */
@Named
public class DiscoverCcNumBaseGenerator implements CcNumBaseGenerator {

    static final String DISCOVER_PREFIX="6";
    static final int DISCOVER_CC_LENGTH =16;

    @Inject
    private GenerateNumber generateNumber;

    @Inject
    private DisplayUtils displayUtils;

    @Override
    public List<String> generateCreditCardNumber(int numOfCard) {
        List<String> discoverCardNumberList = new ArrayList<>();
        int i = 1;
        System.out.println("Number of Discover CC needs to be generated :" + numOfCard);
        while(i <= numOfCard){
            discoverCardNumberList.add(generateNumber.generateCcNumber(DISCOVER_PREFIX,DISCOVER_CC_LENGTH));
        }
        displayUtils.displayListOfString(discoverCardNumberList, CcType.DISCOVER_CARDS.toString());

        return discoverCardNumberList;
    }
}
