package org.interview.rieshr.task.ccnumgenrator.ccfactory;

import org.interview.rieshr.task.ccnumgenrator.util.CcType;
import org.interview.rieshr.task.ccnumgenrator.util.DisplayUtils;
import org.interview.rieshr.task.ccnumgenrator.util.GenerateNumber;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by ashok on 29-09-2018.
 */
@Named
public class MasterCardCcNumBaseGenerator implements CcNumBaseGenerator {

    static final String MASTERCARD_PREFIX="5";
    static final int MASTERCARD_CC_LENGTH =16;

    @Inject
    private GenerateNumber generateNumber;

    @Inject
    private DisplayUtils displayUtils;

    @Override
    public List<String> generateCreditCardNumber(int numOfCard) {
        List<String> mcCardNumberList = new ArrayList<>();
        int i = 1;
        System.out.println("Number of MasterCard CC needs to be generated :" + numOfCard);
        while(i <= numOfCard){
            mcCardNumberList.add(generateNumber.generateCcNumber(MASTERCARD_PREFIX,MASTERCARD_CC_LENGTH));
        }
        displayUtils.displayListOfString(mcCardNumberList, CcType.MASTERCARD.toString());
        return mcCardNumberList;
    }
}
