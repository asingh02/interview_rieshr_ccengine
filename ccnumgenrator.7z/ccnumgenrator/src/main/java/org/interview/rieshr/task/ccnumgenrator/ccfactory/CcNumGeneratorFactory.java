package org.interview.rieshr.task.ccnumgenrator.ccfactory;

import org.interview.rieshr.task.ccnumgenrator.util.CcType;

import javax.inject.Named;


/**
 * Created by Ashok Kr Singh on 30-09-2018.
 */
@Named
public class CcNumGeneratorFactory extends CcNumGenerationBaseFactory{

    @Override
    public CcNumBaseGenerator getCreditCardTypeInstc(String cardType){

        CcNumBaseGenerator ccNumBaseGenerator = null;

        if(cardType.equals(CcType.AMERICAN_EXPRESS.toString())){
            ccNumBaseGenerator = new AmexCcNumBaseGenerator();
        }else if(cardType.equals(CcType.DISCOVER_CARDS.toString())){
            ccNumBaseGenerator =  new DiscoverCcNumBaseGenerator();
        }else if(cardType.equals(CcType.MASTERCARD.toString())){
            ccNumBaseGenerator = new MasterCardCcNumBaseGenerator();
        }else if(cardType.equals(CcType.VISA.toString())){
            ccNumBaseGenerator = new VisaCcNumBaseGenerator();
        }else {
            System.out.println("Card Type :" +cardType +"  is not a valid Card Type");
        }
        return ccNumBaseGenerator;
    }
}
