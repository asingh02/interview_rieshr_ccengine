package org.interview.rieshr.task.ccnumgenrator;

import org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service.CreditCardGenerationRequest;
import org.interview.rieshr.task.ccnumgenrator.ccgenerationengine.service.serviceImpl.CreditCardGenerationRequestImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.inject.Inject;
import java.util.List;

/**
 * Created by Ashok Kr Singh on 29-09-2018.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class CcNumGenratorApplicationTests {

    @Inject
    CreditCardGenerationRequestImpl creditCardGenerationRequest;
    @Test
    public void contextLoads() {
    }

    @Test
    public void generateCreditCards(){
        String str ="VISA";
        int num =10;
        List<String> validList = creditCardGenerationRequest.processRequestForCreditCardGeneration(str,num);
        assert (validList.size() > 0 );
    }

}